package com.posyandu.cilendek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class LupaKatasandi extends AppCompatActivity {
    private ImageView buttonBack,buttonKonfirmasi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lupa_katasandi);

        buttonBack = (ImageView) findViewById(R.id.back_login);
        buttonKonfirmasi = (ImageView) findViewById(R.id.konfirmasi);

        buttonBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openNewActivity("back");
            }
        });

        buttonKonfirmasi.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openNewActivity("konfirmasi");
            }
        });


    }

    public void openNewActivity(String type){

        if(type == "back"){
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
        }else {
            Intent intent = new Intent(this, VerifikasiKode.class);
            startActivity(intent);
            finish();

        }

    }
}