package com.posyandu.cilendek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class VerifikasiKode extends AppCompatActivity {
    private ImageView buttonBack,buttonKonfirmasi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifikasi_kode);



        buttonBack = (ImageView) findViewById(R.id.back_lupa_kata_sandi);
        buttonBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openNewActivity("back");
            }
        });


        buttonKonfirmasi = (ImageView) findViewById(R.id.konfirmasi);
        buttonKonfirmasi.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openNewActivity("konfirmasi");
            }
        });

    }

    public void openNewActivity(String type){

        if(type == "back"){
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
        }else {
            Intent intent = new Intent(this, GantiKataSandi.class);
            startActivity(intent);
            finish();

        }

    }
}