package com.posyandu.cilendek.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.posyandu.cilendek.R;


public class AddParentDataActivity extends AppCompatActivity {

    //variable
    ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parent_data);

        //variable implement
        btnBack = (ImageView) findViewById(R.id.back);


        //action
        btnBack.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}