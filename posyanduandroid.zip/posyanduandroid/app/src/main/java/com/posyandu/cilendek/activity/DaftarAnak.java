package com.posyandu.cilendek.activity;

        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.os.Parcelable;
        import android.util.Log;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ListView;

        import androidx.appcompat.app.ActionBar;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.appcompat.widget.Toolbar;

        import com.posyandu.cilendek.R;
        import com.posyandu.cilendek.adapter.ChildAdapter;
        import com.posyandu.cilendek.model.Child;
        import com.posyandu.cilendek.respon.ChildResponse;
        import com.posyandu.cilendek.service.ChildApi;
        import com.google.android.material.floatingactionbutton.FloatingActionButton;

        import java.io.IOException;
        import java.util.ArrayList;
        import java.util.List;

        import okhttp3.Interceptor;
        import okhttp3.OkHttpClient;
        import okhttp3.Request;
        import retrofit2.Call;
        import retrofit2.Callback;
        import retrofit2.Response;
        import retrofit2.Retrofit;
        import retrofit2.converter.gson.GsonConverterFactory;

public class DaftarAnak extends AppCompatActivity {
    private ListView listView;
    private ChildAdapter adapter;
    private List<Child> childList;
    private ChildApi childApi;
    private String authToken; // Simpan token autentikasi di sini

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_anak);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
        listView = findViewById(R.id.listView);
        childList = new ArrayList<>();
        adapter = new ChildAdapter(this, childList);
        listView.setAdapter(adapter);

        authToken = getIntent().getStringExtra("authToken");
        if (authToken == null) {
            SharedPreferences sharedPreferences = getSharedPreferences("my_preferences", MODE_PRIVATE);
            authToken = sharedPreferences.getString("authToken", null);
        }
        // Inisialisasi Retrofit dengan Interceptor
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public okhttp3.Response intercept(Chain chain) throws IOException {
                        Request originalRequest = chain.request();
                        Request.Builder requestBuilder = originalRequest.newBuilder()
                                .header("Authorization", "Bearer " + authToken);
                        Request request = requestBuilder.build();
                        return chain.proceed(request);
                    }
                })
                .build();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToInputDataAnak();
            }
        });


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.posyandu.serverwan.com/api/")
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        childApi = retrofit.create(ChildApi.class);

        // Lakukan permintaan ke API menggunakan Retrofit
        Call<ChildResponse> call = childApi.getChildren();
        call.enqueue(new Callback<ChildResponse>() {
            @Override
            public void onResponse(Call<ChildResponse> call, Response<ChildResponse> response) {
                if (response.isSuccessful()) {
                    ChildResponse childResponse = response.body();
                    if (childResponse != null && childResponse.isStatus()) {
                        childList.addAll(childResponse.getData());
                        adapter.notifyDataSetChanged();
                    } else {
                        Log.d("API", "Response with false status: " + response.raw().toString());
                    }
                } else {
                    Log.d("API", "Unsuccessful response: " + response.raw().toString());
                }
            }

            @Override
            public void onFailure(Call<ChildResponse> call, Throwable t) {
                Log.e("API", "Error: " + t.getMessage());
            }

        });


        // Tambahkan listener untuk item ListView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Dapatkan data anak yang diklik
                Child child = childList.get(position);

                // Buat intent untuk membuka aktivitas DetailAnak
                Intent intent = new Intent(DaftarAnak.this, DetailAnakActivity.class);
                intent.putExtra("child", (Parcelable) child);
                // Start aktivitas DetailAnak
                startActivity(intent);
            }
        });
    }

    private void navigateToInputDataAnak() {
        Intent intent = new Intent(DaftarAnak.this, InputDataAnak.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            // Tombol kembali di ActionBar ditekan
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}


