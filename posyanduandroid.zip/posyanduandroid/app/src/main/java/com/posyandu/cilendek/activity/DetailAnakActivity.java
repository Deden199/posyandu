package com.posyandu.cilendek.activity;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.posyandu.cilendek.R;
import com.posyandu.cilendek.model.Anak;
import com.posyandu.cilendek.model.Child;
import com.posyandu.cilendek.respon.ChildResponse;
import com.posyandu.cilendek.service.ChildApi;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DetailAnakActivity extends AppCompatActivity {
    private Anak anak;
    private TextView textViewName;
    private TextView textViewParent;
    private TextView textViewNIK;
    private TextView textViewGender;
    private TextView textViewBornPlace;
    private TextView textViewBornDate;
    private TextView textViewChildTo;
    private TextView textViewIsIMD;
    private TextView textViewStatus;
    private TextView textViewTotalAge;
    private TextView textViewCurrentWeight;
    private TextView textViewCurrentHeight;
    private TextView textViewCurrentHead;
    private TextView textViewCurrentArm;
    private TextView textViewCurrentChest;
    private LinearLayout layoutMeasurements;

    private ChildApi childApi;
    private String authToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_anak);

        grid();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
        // Inisialisasi tampilan
        textViewName = findViewById(R.id.name);
        textViewParent = findViewById(R.id.parents);
        textViewNIK = findViewById(R.id.nik);
//        textViewGender = findViewById(R.id.textViewGender);
//        textViewBornPlace = findViewById(R.id.textViewBornPlace);
//        textViewBornDate = findViewById(R.id.textViewBornDate);
//        textViewChildTo = findViewById(R.id.textViewChildTo);
//        textViewIsIMD = findViewById(R.id.textViewIsIMD);
//        textViewStatus = findViewById(R.id.textViewStatus);
        textViewTotalAge = findViewById(R.id.age);
        textViewCurrentWeight = findViewById(R.id.item1_desc);
        textViewCurrentHeight = findViewById(R.id.item2_desc);
        textViewCurrentHead = findViewById(R.id.item3_desc);
        textViewCurrentArm = findViewById(R.id.item4_desc);
        textViewCurrentChest = findViewById(R.id.item5_desc);
//        layoutMeasurements = findViewById(R.id.layoutMeasurements);


        // Mendapatkan data anak dari intent
        Child child = getIntent().getParcelableExtra("child");
        if (child != null) {
            displayChildData(child);
        }

        // Mendapatkan authToken
        authToken = getIntent().getStringExtra("authToken");

        // Inisialisasi Retrofit dengan Interceptor
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public okhttp3.Response intercept(Chain chain) throws IOException {
                        Request originalRequest = chain.request();
                        Request.Builder requestBuilder = originalRequest.newBuilder()
                                .header("Authorization", "Bearer " + authToken);
                        Request request = requestBuilder.build();
                        return chain.proceed(request);
                    }
                })
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.posyandu.serverwan.com/api/")
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        childApi = retrofit.create(ChildApi.class);

        // Lakukan permintaan ke API untuk mendapatkan data anak
        Call<ChildResponse> call = childApi.getChild(child.getId());
        call.enqueue(new Callback<ChildResponse>() {
            @Override
            public void onResponse(Call<ChildResponse> call, Response<ChildResponse> response) {
                if (response.isSuccessful()) {
                    ChildResponse childResponse = response.body();
                    if (childResponse != null && childResponse.isStatus()) {
                        Child updatedChild = (Child) childResponse.getData();
                        displayChildData(updatedChild);
                    } else {
                        Log.d("API", "Response with false status: " + response.raw().toString());
                    }
                } else {
                    Log.d("API", "Unsuccessful response: " + response.raw().toString());
                }
            }

                @Override
                public void onFailure(Call<ChildResponse> call, Throwable t) {
                    Log.e("API", "Error: " + t.getMessage());
                }
            });







    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            // Tombol kembali di ActionBar ditekan
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    // Menangani aksi ketika tombol back pada perangkat ditekan
    @Override
    public void onBackPressed() {
        // your code here
        super.onBackPressed();
    }

        // Menampilkan data anak pada tampilan
        private void displayChildData(Child child) {
            textViewName.setText(child.getName());
            textViewParent.setText("Jenis Kelamin : " + child.getGender());
            textViewNIK.setText("NIK : " + child.getNik());
//            textViewGender.setText(child.getGender());
//            textViewBornPlace.setText(child.getBornPlace());
//            textViewBornDate.setText(child.getBornDate());
//            textViewChildTo.setText(String.valueOf(child.getChildTo()));
//            textViewIsIMD.setText(String.valueOf(child.getIsImd()));
//            textViewStatus.setText(child.getStatus());
            textViewTotalAge.setText("Umur: "+child.getTotalAge()+"Bulan");
//            textViewCurrentWeight.setText(child.getCurrentWeight());
//            textViewCurrentHeight.setText(child.getCurrentHeight());
//            textViewCurrentHead.setText(child.getCurrentHead());
//            textViewCurrentArm.setText(child.getCurrentArm());
//            textViewCurrentChest.setText(child.getCurrentChest());
//
//            layoutMeasurements.removeAllViews();

//            List<Measurement> measurements = child.getMeasurements();
//            for (Measurement measurement : measurements) {
//                View measurementView = getLayoutInflater().inflate(R.layout.item_measurement, null);
//                TextView textViewType = measurementView.findViewById(R.id.textViewType);
//                TextView textViewInMonthTo = measurementView.findViewById(R.id.textViewInMonthTo);
//                TextView textViewAmount = measurementView.findViewById(R.id.textViewAmount);
//
//                textViewType.setText(measurement.getType());
//                textViewInMonthTo.setText(String.valueOf(measurement.getInMonthTo()));
//                textViewAmount.setText(String.valueOf(measurement.getAmount()));
//
//                layoutMeasurements.addView(measurementView);
//            }
//        }

        }
    public void grid() {
        RelativeLayout item1 = findViewById(R.id.item1);
        item1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatBeratBadanActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout item2 = findViewById(R.id.item2);
        item2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatTinggiBadanActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout item3 = findViewById(R.id.item3);
        item3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatLingkarKepalaActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout item4 = findViewById(R.id.item4);
        item4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatLingkarLenganAtasActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout item5 = findViewById(R.id.item5);
        item5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatLingkarDadaActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout item6 = findViewById(R.id.item6);
        item6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatVitaminActivity.class);
                startActivity(intent);
            }
        });
        RelativeLayout item7 = findViewById(R.id.item7);
        item7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, RiwayatAsiActivity.class);
                startActivity(intent);
            }
        });

        RelativeLayout item8 = findViewById(R.id.item8);
        item8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailAnakActivity.this, Kms.class);
                startActivity(intent);
            }
        });
    }
}