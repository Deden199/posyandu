package com.posyandu.cilendek.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.posyandu.cilendek.R;


public class DetailParentDataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_parent_data);
    }
}