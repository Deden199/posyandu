package com.posyandu.cilendek.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.posyandu.cilendek.R;


public class HomeActivity extends AppCompatActivity {

    ImageButton btnParentData;
    ImageButton dataanak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnParentData = (ImageButton) findViewById(R.id.btn_data_parent);
        dataanak = (ImageButton) findViewById(R.id.data_children);

        btnParentData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewParentData = new Intent(getApplicationContext(), ParentDataActivity.class);
                startActivity(viewParentData);
            }
        });


        dataanak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewParentData = new Intent(getApplicationContext(), DaftarAnak.class);
                startActivity(viewParentData);
            }
        });
    }
}