package com.posyandu.cilendek.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.posyandu.cilendek.R;
import com.posyandu.cilendek.model.Child;
import com.posyandu.cilendek.service.ChildApi;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;

import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.Locale;

public class InputDataAnak extends AppCompatActivity {

    private EditText nameEditText, nikEditText;
    private Spinner parentSpinner;
    private RadioGroup genderRadioGroup;
    private RadioButton maleRadioButton, femaleRadioButton;
    private ChildApi childApi;
    private String authToken;
    private DatePicker birthdatePicker;
    private EditText childOrderEditText;
    private RadioGroup initiationRadioGroup;
    private RadioButton yesRadioButton;
    private RadioButton noRadioButton;
    private EditText birthWeightEditText;
    private EditText birthLengthEditText;
    private EditText birthHeadCircumferenceEditText, bornPlaceEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_data_anak);

        // Find views
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_back);

        authToken = getIntent().getStringExtra("authToken");
        if (authToken == null) {
            SharedPreferences sharedPreferences = getSharedPreferences("my_preferences", MODE_PRIVATE);
            authToken = sharedPreferences.getString("authToken", null);
        }

        // Initialize Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.posyandu.serverwan.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(getOkHttpClient())
                .build();

        childApi = retrofit.create(ChildApi.class);

        // Initialize views
        nameEditText = findViewById(R.id.name_edit_text);
        nikEditText = findViewById(R.id.nik_edit_text);
        parentSpinner = findViewById(R.id.parent_spinner);
        genderRadioGroup = findViewById(R.id.gender_radio_group);
        maleRadioButton = findViewById(R.id.male_radio_button);
        femaleRadioButton = findViewById(R.id.female_radio_button);
        bornPlaceEditText = findViewById(R.id.bornPlaceEditText);


        // Set onClickListener for the male radio button
        maleRadioButton.setOnClickListener(view -> {
            // Show snackbar or perform any action
        });

        // Set onClickListener for the female radio button
        femaleRadioButton.setOnClickListener(view -> {
            // Show snackbar or perform any action
        });

        // Set up parent spinner
        ArrayAdapter<CharSequence> parentAdapter = ArrayAdapter.createFromResource(InputDataAnak.this,
                R.array.parent_array, android.R.layout.simple_spinner_item);

        parentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        parentSpinner.setAdapter(parentAdapter);
        parentSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String parent = adapterView.getItemAtPosition(position).toString();
                Child child = new Child();
                int parentId = getParentId(parent); // Dapatkan ID induk berdasarkan induk yang dipilih
                child.setParentId(parentId);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });


        // Find additional views
        birthdatePicker = findViewById(R.id.birthdate_picker);
        childOrderEditText = findViewById(R.id.child_order_edit_text);
        initiationRadioGroup = findViewById(R.id.initiation_radio_group);
        yesRadioButton = findViewById(R.id.yes_radio_button);
        noRadioButton = findViewById(R.id.no_radio_button);
        birthWeightEditText = findViewById(R.id.birth_weight_edit_text);
        birthLengthEditText = findViewById(R.id.birth_length_edit_text);
        birthHeadCircumferenceEditText = findViewById(R.id.birth_head_circumference_edit_text);

        // Set onClickListener for the male radio button
        maleRadioButton.setOnClickListener(view -> {
            // Show snackbar or perform any action
        });

        // Set onClickListener for the female radio button
        femaleRadioButton.setOnClickListener(view -> {
            // Show snackbar or perform any action
        });

        // Handle button click event
        ImageView submitButton = findViewById(R.id.save);
        submitButton.setOnClickListener(view -> {
            // Get values from the form fields
            String name = nameEditText.getText().toString();
            String nik = nikEditText.getText().toString();
            String parent = parentSpinner.getSelectedItem().toString();
            String gender = genderRadioGroup.getCheckedRadioButtonId() == R.id.male_radio_button ? "Laki Laki" : "Perempuan";
            String bornPlace = bornPlaceEditText.getText().toString();
            String bornDate = getFormattedBirthDate();
            int childOrder = Integer.parseInt(childOrderEditText.getText().toString());
            boolean isImd = initiationRadioGroup.getCheckedRadioButtonId() == R.id.yes_radio_button;
            double weight = Double.parseDouble(birthWeightEditText.getText().toString());
            double length = Double.parseDouble(birthLengthEditText.getText().toString());
            double headCircumference = Double.parseDouble(birthHeadCircumferenceEditText.getText().toString());

            // Buat objek ChildApi dari Retrofit
//            ChildApi childApi = retrofit.create(ChildApi.class);

//            Child child = new Child();
//            child.setParentId(3);
//            // Create a Child object
//            child.setName(name);
//            child.setNik(nik);
//            child.setParents(parent);
//            child.setGender(gender);
//            child.setBornPlace(bornPlace);
//            child.setBornDate(bornDate);
//            child.setChildOrder(childOrder);
//            child.setIsImd(isImd);
//            child.setWeight(weight);
//            child.setLength(length);
//            child.setHeadCircumference(headCircumference);

// Execute the network call on a background thread
            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(new Interceptor() {
                        @Override
                        public okhttp3.Response intercept(Chain chain) throws IOException {
                            Request originalRequest = chain.request();
                            Request.Builder requestBuilder = originalRequest.newBuilder()
                                    .header("Authorization", "Bearer " + authToken)
                                    .method(originalRequest.method(), originalRequest.body());
                            Request request = requestBuilder.build();
                            return chain.proceed(request);
                        }
                    })
                    .build();

            new Thread(() -> {
                MediaType mediaType = MediaType.parse("text/plain");
                RequestBody body = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("parent_id", "1")
                        .addFormDataPart("name", name)
                        .addFormDataPart("nik", nik)
                        .addFormDataPart("gender", gender)
                        .addFormDataPart("born_place", bornPlace)
                        .addFormDataPart("born_date", bornDate)
                        .addFormDataPart("child_to", String.valueOf(childOrder))
                        .addFormDataPart("is_imd", isImd ? "1" : "0")
                        .addFormDataPart("weight", String.valueOf(weight))
                        .addFormDataPart("height", String.valueOf(length))
                        .addFormDataPart("head_circumference", String.valueOf(headCircumference))
                        .build();


                Request request = new Request.Builder()
                        .url("https://api.posyandu.serverwan.com/api/child")
                        .method("POST", body)
                        .build();

                try {
                    okhttp3.Response response = client.newCall(request).execute();
                    int responseCode = response.code();
                    if (responseCode == 200) {
                        // Handle successful response (status code 200)
                        runOnUiThread(() -> {
                            Toast.makeText(InputDataAnak.this, "Data anak berhasil disimpan", Toast.LENGTH_SHORT).show();

                            // Move to DaftarAnak activity
                            Intent intent = new Intent(InputDataAnak.this, DaftarAnak.class);
                            startActivity(intent);
                            finish();
                        });
                    } else {
                        // Handle other response codes
                        runOnUiThread(() -> {
                            Toast.makeText(InputDataAnak.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                            Log.e("InputDataAnak", "Response code: " + responseCode);

                        });
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("InputDataAnak", "IOException: " + e.getMessage());

                }
            }).start();



//// Call the API to submit the child data
//            retrofit2.Call<Child> call = childApi.createChild(child);
//            call.enqueue(new Callback<Child>() {
//             @Override
//                public void onResponse(Call<Child> call, Response<Child> response) {
//                    if (response.isSuccessful()) {
//                        // Child data submitted successfully
//                        Child submittedChild = response.body();
//                        Toast.makeText(InputDataAnak.this, "Data anak berhasil disimpan", Toast.LENGTH_SHORT).show();
//
//                        // Move to DaftarAnak activity
//                        Intent intent = new Intent(InputDataAnak.this, DaftarAnak.class);
//                        startActivity(intent);
//                        finish();
//                        // Handle the response as needed
//                    } else if (response.code() == 422) {
//                        // Error submitting child data due to validation error
//                        // Handle the validation error response
//                        try {
//                            String errorBody = response.errorBody().string();
//                            Toast.makeText(InputDataAnak.this, "Isian parent id wajib diisi", Toast.LENGTH_SHORT).show();
//
//                            Log.d("InputDataAnak", "Validation error response: " + errorBody);
//                            // Parse and handle the error body
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    } else {
//                        // Error submitting child data
//                        // Handle other error responses
//                    }
//                }
//
//
//                @Override
//                public void onFailure(Call<Child> call, Throwable t) {
//                    // Error submitting child data
//                    // Handle the failure
//                    Toast.makeText(InputDataAnak.this, "Gagal menyimpan data anak: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//                    Log.d("InputDataAnak", "onFailure: " + t.getMessage());
//
//                }
//            });
//
//
//        });
//        }


        });
    }

            private OkHttpClient getOkHttpClient () {
                return new OkHttpClient.Builder()
                        .addInterceptor(chain -> {
                            Request originalRequest = chain.request();
                            Request.Builder requestBuilder = originalRequest.newBuilder()
                                    .header("Authorization", "Bearer " + authToken);
                            Request request = requestBuilder.build();
                            return chain.proceed(request);
                        })
                        .build();
            }

    private int getParentId(String parent) {
        // Implementasikan logika untuk mendapatkan ID induk berdasarkan nama induk
        // Misalnya, lakukan query ke database atau lakukan pengecekan pada koleksi data
        // dan kembalikan ID yang sesuai.
        // Contoh sederhana:
        if (parent.equals("Induk A")) {
            return 1;
        } else if (parent.equals("Induk B")) {
            return 2;
        } else if (parent.equals("Induk C")) {
            return 3;
        } else {
            return 0; // Jika tidak ada induk yang cocok, kembalikan nilai default atau kode error
        }
    }


    private String getFormattedBirthDate() {
        int year = birthdatePicker.getYear();
        int month = birthdatePicker.getMonth() + 1; // Months are zero-based
        int day = birthdatePicker.getDayOfMonth();

        // Format the date as needed (e.g., "yyyy-MM-dd")
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day);
    }
            @Override
            public boolean onOptionsItemSelected (MenuItem item){
                switch (item.getItemId()) {
                    case android.R.id.home:
                        onBackPressed();
                        return true;
                }
                return super.onOptionsItemSelected(item);
            }
        }


