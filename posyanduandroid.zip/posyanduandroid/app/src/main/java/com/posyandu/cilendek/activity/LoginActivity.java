package com.posyandu.cilendek.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.posyandu.cilendek.LupaKatasandi;
import com.posyandu.cilendek.R;
import com.posyandu.cilendek.respon.AuthResponse;
import com.posyandu.cilendek.service.AuthApi;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.content.Context;
import android.content.SharedPreferences;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private EditText inputEmail, inputPassword;
    private ImageView btnLogin;
    private AuthApi authApi;
    private SharedPreferences sharedPreferences;
    private TextView button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        button = (TextView) findViewById(R.id.lupa_kata_sandi);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, LupaKatasandi.class);
                startActivity(intent);            }
        });
        inputEmail = findViewById(R.id.email_login);
        inputPassword = findViewById(R.id.password_login);
        btnLogin = findViewById(R.id.loginbtn);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.posyandu.serverwan.com/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        authApi = retrofit.create(AuthApi.class);
        sharedPreferences = getSharedPreferences("my_preferences", Context.MODE_PRIVATE);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        checkLoggedInStatus();
    }

    private void login() {
        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();

        Call<AuthResponse> call = authApi.login(email, password);
        call.enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {
                if (response.isSuccessful()) {
                    AuthResponse authResponse = response.body();
                    if (authResponse != null && authResponse.isSuccess()) {
                        // Login berhasil, simpan token autentikasi dan kredensial di sini
                        String authToken = authResponse.getToken();
                        saveAuthToken(authToken);
                        // Lanjutkan ke halaman DaftarAnak
                        Intent intent = new Intent(LoginActivity.this, DaftarAnak.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveAuthToken(String authToken) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("authToken", authToken);
        editor.putBoolean("logged_in", true);
        editor.apply();
    }

    private void checkLoggedInStatus() {
        boolean isLoggedIn = sharedPreferences.getBoolean("logged_in", false);
        if (isLoggedIn) {
            // Pengguna telah login sebelumnya, arahkan ke halaman berikutnya
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        }
    }
}
