package com.posyandu.cilendek.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.posyandu.cilendek.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ParentDataActivity extends AppCompatActivity {

    //variable
    FloatingActionButton floatingActionButton;
    ImageView btnBack;
    LinearLayout detailDataParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_data);

        //variable implement
        floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        btnBack = (ImageView) findViewById(R.id.back);
        detailDataParent = (LinearLayout) findViewById(R.id.detail_parent_data);


        //action
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewAddParentData = new Intent(getApplicationContext(), AddParentDataActivity.class);
                startActivity(viewAddParentData);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        detailDataParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewDetailParentData = new Intent(getApplicationContext(), DetailParentDataActivity.class);
                startActivity(viewDetailParentData);
            }
        });
    }

}