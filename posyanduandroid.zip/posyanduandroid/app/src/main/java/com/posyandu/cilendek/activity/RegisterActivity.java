package com.posyandu.cilendek.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.posyandu.cilendek.R;

import okhttp3.*;

import java.io.IOException;

public class RegisterActivity extends AppCompatActivity {
    private EditText inputName, inputEmail, inputPhone, inputPuskesmasName, inputTotalKader, inputProvinceId, inputCityId, inputSubdistrictId, inputVillage, inputAddress, inputPassword, inputPasswordConfirmation;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        inputName = findViewById(R.id.input_name);
        inputEmail = findViewById(R.id.input_email);
        inputPhone = findViewById(R.id.input_phone);
        inputPuskesmasName = findViewById(R.id.input_puskesmas_name);
        inputTotalKader = findViewById(R.id.input_total_kader);
        inputProvinceId = findViewById(R.id.input_province_id);
        inputCityId = findViewById(R.id.input_city_id);
        inputSubdistrictId = findViewById(R.id.input_subdistrict_id);
        inputVillage = findViewById(R.id.input_village);
        inputAddress = findViewById(R.id.input_address);
        inputPassword = findViewById(R.id.input_password);
        inputPasswordConfirmation = findViewById(R.id.input_password_confirmation);
        btnRegister = findViewById(R.id.btn_register);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
    }

    private void register() {
        String name = inputName.getText().toString().trim();
        String email = inputEmail.getText().toString().trim();
        String phone = inputPhone.getText().toString().trim();
        String puskesmasName = inputPuskesmasName.getText().toString().trim();
        String totalKader = inputTotalKader.getText().toString().trim();
        String provinceId = inputProvinceId.getText().toString().trim();
        String cityId = inputCityId.getText().toString().trim();
        String subdistrictId = inputSubdistrictId.getText().toString().trim();
        String village = inputVillage.getText().toString().trim();
        String address = inputAddress.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();
        String passwordConfirmation = inputPasswordConfirmation.getText().toString().trim();

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("email", email)
                .addFormDataPart("name", name)
                .addFormDataPart("puskesmas_name", puskesmasName)
                .addFormDataPart("total_kader", totalKader)
                .addFormDataPart("phone", phone)
                .addFormDataPart("province_id", provinceId)
                .addFormDataPart("city_id", cityId)
                .addFormDataPart("subdistrict_id", subdistrictId)
                .addFormDataPart("village", village)
                .addFormDataPart("address", address)
                .addFormDataPart("password", password)
                .addFormDataPart("password_confirmation", passwordConfirmation)
                .build();
        Request request = new Request.Builder()
                .url("https://api.posyandu.serverwan.com/api/register")
                .method("POST", body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}

