package com.posyandu.cilendek.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.posyandu.cilendek.R;

public class RiwayatAsiActivity extends AppCompatActivity {
    private TextView namaTextView, nikTextView, orangtuaTextView, umurTextView;
    private ImageView fotoImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat_asi);

//        SharedPreferences sharedPref = getSharedPreferences("data_anak", MODE_PRIVATE);
//        String nama = sharedPref.getString("nama", "");
//        String nik = sharedPref.getString("nik", "");
//        String orangtua = sharedPref.getString("orangtua", "");
//        int umur = sharedPref.getInt("umur", 0);
//        int foto = sharedPref.getInt("foto", 0);
//
//        namaTextView = findViewById(R.id.name);
//        nikTextView = findViewById(R.id.nik);
//        orangtuaTextView = findViewById(R.id.parents);
//        umurTextView = findViewById(R.id.age);
//        fotoImageView = findViewById(R.id.photo);
//
//
//        // Menampilkan data pada tampilan
//        namaTextView.setText(nama);
//        nikTextView.setText(nik);
//        orangtuaTextView.setText(orangtua);
//        umurTextView.setText(String.valueOf(umur));
//        fotoImageView.setImageResource(foto);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Menambahkan tombol kembali pada action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Menangani aksi ketika tombol back pada perangkat ditekan
    @Override
    public void onBackPressed() {
        // your code here
        super.onBackPressed();
    }
}