package com.posyandu.cilendek.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.posyandu.cilendek.R;

public class RiwayatLingkarLenganAtasActivity extends AppCompatActivity {
    private TextView namaTextView, nikTextView, orangtuaTextView, umurTextView;
    private ImageView fotoImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat_lingkar_lengat_atas);
        CardView popup = findViewById(R.id.pop);
        ImageView fab = findViewById(R.id.fab);
        popup.setVisibility(View.GONE);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fab.setVisibility(View.GONE);
                popup.setVisibility(View.VISIBLE);

            }
        });


        popup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fab.setVisibility(View.VISIBLE);
                popup.setVisibility(View.GONE);

            }
        });
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Menambahkan tombol kembali pada action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Menangani aksi ketika tombol back pada perangkat ditekan
    @Override
    public void onBackPressed() {
        // your code here
        super.onBackPressed();
    }
}