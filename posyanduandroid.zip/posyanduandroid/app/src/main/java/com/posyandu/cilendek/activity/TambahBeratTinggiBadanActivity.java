package com.posyandu.cilendek.activity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupWindow;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.posyandu.cilendek.R;

public class TambahBeratTinggiBadanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_tambah_tinggi_badan);
        ImageView cariPerangkat = findViewById(R.id.cariperangkat);
        cariPerangkat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupWindow popup = new PopupWindow(TambahBeratTinggiBadanActivity.this);
                View layout = getLayoutInflater().inflate(R.layout.popup_device, null);
                popup.setContentView(layout);
                popup.setBackgroundDrawable(null); // menghilangkan garis tepi

                // Menambahkan listener pada parent view
                View parentView = findViewById(android.R.id.content);
                parentView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popup.dismiss(); // Menutup popup saat terjadi aksi klik diluar popup
                        return true;
                    }
                });

                popup.showAtLocation(v, Gravity.CENTER, 0, 0);
            }
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Menambahkan tombol kembali pada action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Menangani aksi ketika tombol back pada perangkat ditekan
    @Override
    public void onBackPressed() {
        // your code here
        super.onBackPressed();
    }
}