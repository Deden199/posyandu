package com.posyandu.cilendek.adapter;

public class AdapterParentData {
}
