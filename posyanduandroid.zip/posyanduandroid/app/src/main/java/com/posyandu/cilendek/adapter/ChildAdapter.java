package com.posyandu.cilendek.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.posyandu.cilendek.R;
import com.posyandu.cilendek.model.Child;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ChildAdapter extends ArrayAdapter<Child> {
    private Context context;
    private List<Child> childList;

    public ChildAdapter(Context context, List<Child> childList) {
        super(context, 0, childList);
        this.context = context;
        this.childList = childList;
    }

    @Override
    public View getView(int position, @Nullable View convertView,  ViewGroup parent) {
        View itemView = convertView;
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.card_anak, parent, false);
        }

        Child currentChild = childList.get(position);

        TextView nameTextView = itemView.findViewById(R.id.name);
        TextView nikTextView = itemView.findViewById(R.id.nik);
        TextView parentsTextView = itemView.findViewById(R.id.parents);
        TextView totalAgeTextView = itemView.findViewById(R.id.age);

        nameTextView.setText(currentChild.getName());
        nikTextView.setText("Nik : " +currentChild.getNik());
        parentsTextView.setText("Orang Tua : " +currentChild.getParents());
        totalAgeTextView.setText("Umur : " +String.valueOf(currentChild.getTotalAge()+" Bulan"));

        return itemView;
    }
}

