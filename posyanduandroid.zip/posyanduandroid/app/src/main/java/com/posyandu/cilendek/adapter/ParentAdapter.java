package com.posyandu.cilendek.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.posyandu.cilendek.R;
import com.posyandu.cilendek.model.Parent;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ParentAdapter extends ArrayAdapter<Parent> {
    private Context context;
    private List<Parent> parentList;

    public ParentAdapter(Context context, List<Parent> parentList) {
        super(context, 0, parentList);
        this.context = context;
        this.parentList = parentList;
    }

    @Override
    public View getView(int position, @Nullable View convertView,  ViewGroup parent) {
        View itemView = convertView;
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.card_anak, parent, false);
        }

        Parent currentParent = parentList.get(position);

        TextView nameTextView = itemView.findViewById(R.id.name);
        TextView nikTextView = itemView.findViewById(R.id.nik);

        nameTextView.setText(currentParent.getParents());
        nikTextView.setText(currentParent.getNik());

        return itemView;
    }
}
