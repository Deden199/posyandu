package com.posyandu.cilendek.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Anak implements Parcelable {
    private String nama;
    private String nik;
    private String orangtua;
    private int umur;
    private int foto;

    public Anak(String nama, String nik, String orangtua, int umur, int foto) {
        this.nama = nama;
        this.nik = nik;
        this.orangtua = orangtua;
        this.umur = umur;
        this.foto = foto;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

    public String getOrangtua() {
        return orangtua;
    }

    public void setOrangtua(String orangtua) {
        this.orangtua = orangtua;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    // Implementasi Parcelable
    protected Anak(Parcel in) {
        nama = in.readString();
        nik = in.readString();
        orangtua = in.readString();
        umur = in.readInt();
        foto = in.readInt();
    }

    public static final Creator<Anak> CREATOR = new Creator<Anak>() {
        @Override
        public Anak createFromParcel(Parcel in) {
            return new Anak(in);
        }

        @Override
        public Anak[] newArray(int size) {
            return new Anak[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nama);
        dest.writeString(nik);
        dest.writeString(orangtua);
        dest.writeInt(umur);
        dest.writeInt(foto);
    }
}
