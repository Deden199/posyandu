package com.posyandu.cilendek.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Child implements Parcelable {
    private int id;
    private String name;
    private String nik;
    private String parents;
    private int total_age;
    private String gender;
    private String born_place;
    private String born_date;
    private int child_to;
    private int is_imd;
    private String status;
    private String current_weight;
    private String current_height;
    private String current_head;
    private String current_arm;
    private String current_chest;
    private int childOrder;
    private boolean isImd;
    private double weight;
    private double length;
    private double headCircumference;
    private int parentId;

    public Child() {

    }

    public int getChildOrder() {
        return childOrder;
    }

    public void setChildOrder(int childOrder) {
        this.childOrder = childOrder;
    }


    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getHeadCircumference() {
        return headCircumference;
    }

    public void setHeadCircumference(double headCircumference) {
        this.headCircumference = headCircumference;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parent_Id) {
        this.parentId = parent_Id;
    }

    public boolean getIsImd() {
        return isImd;
    }

    public void setIsImd(boolean isImd) {
        this.isImd = isImd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

    public String getParents() {
        return parents;
    }

    public void setParents(String parents) {
        this.parents = parents;
    }

    public int getTotalAge() {
        return total_age;
    }

    public void setTotalAge(int totalAge) {
        this.total_age = totalAge;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBornPlace() {
        return born_place;
    }

    public void setBornPlace(String bornPlace) {
        this.born_place = bornPlace;
    }

    public String getBornDate() {
        return born_date;
    }

    public void setBornDate(String bornDate) {
        this.born_date = bornDate;
    }

    public int getChildTo() {
        return child_to;
    }

    public void setChildTo(int childTo) {
        this.child_to = childTo;
    }



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrentWeight() {
        return current_weight;
    }

    public void setCurrentWeight(String currentWeight) {
        this.current_weight = currentWeight;
    }

    public String getCurrentHeight() {
        return current_height;
    }

    public void setCurrentHeight(String currentHeight) {
        this.current_height = currentHeight;
    }

    public String getCurrentHead() {
        return current_head;
    }

    public void setCurrentHead(String currentHead) {
        this.current_head = currentHead;
    }

    public String getCurrentArm() {
        return current_arm;
    }

    public void setCurrentArm(String currentArm) {
        this.current_arm = currentArm;
    }

    public String getCurrentChest() {
        return current_chest;
    }

    public void setCurrentChest(String currentChest) {
        this.current_chest = currentChest;
    }

    // Implementasi Parcelable
    public Child(Parcel in) {
        id = in.readInt();
        name = in.readString();
        nik = in.readString();
        parents = in.readString();
        total_age = in.readInt();
        gender = in.readString();
        born_place = in.readString();
        born_date = in.readString();
        child_to = in.readInt();
        is_imd = in.readInt();
        status = in.readString();
        current_weight = in.readString();
        current_height = in.readString();
        current_head = in.readString();
        current_arm = in.readString();
        current_chest = in.readString();
    }

    public static final Creator<Child> CREATOR = new Creator<Child>() {
        @Override
        public Child createFromParcel(Parcel in) {
            return new Child(in);
        }

        @Override
        public Child[] newArray(int size) {
            return new Child[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(nik);
        dest.writeString(parents);
        dest.writeInt(total_age);
        dest.writeString(gender);
        dest.writeString(born_place);
        dest.writeString(born_date);
        dest.writeInt(child_to);
        dest.writeInt(is_imd);
        dest.writeString(status);
        dest.writeString(current_weight);
        dest.writeString(current_height);
        dest.writeString(current_head);
        dest.writeString(current_arm);
        dest.writeString(current_chest);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}

