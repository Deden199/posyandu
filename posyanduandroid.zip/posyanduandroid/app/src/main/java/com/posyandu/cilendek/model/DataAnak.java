package com.posyandu.cilendek.model;

public class DataAnak {
    private String nama;
    private String nik;
    private String orangtua;
    private int umur;
    private int foto;

    public DataAnak(String nama, String nik, String orangtua, int umur, int foto) {
        this.nama = nama;
        this.nik = nik;
        this.orangtua = orangtua;
        this.umur = umur;
        this.foto = foto;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }

    public String getOrangtua() {
        return orangtua;
    }

    public void setOrangtua(String orangtua) {
        this.orangtua = orangtua;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }
}
