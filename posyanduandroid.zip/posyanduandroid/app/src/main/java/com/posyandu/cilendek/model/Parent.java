package com.posyandu.cilendek.model;

public class Parent {
    private int id;
    private String parents;
    private String nik;
    private int total_child;

    public int getId() {
        return id;
    }

    public String getParents() {
        return parents;
    }

    public String getNik() {
        return nik;
    }

    public int getTotalChild() {
        return total_child;
    }
}
