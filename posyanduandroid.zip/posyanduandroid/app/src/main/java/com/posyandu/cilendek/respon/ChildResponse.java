package com.posyandu.cilendek.respon;

import com.posyandu.cilendek.model.Child;

import java.util.List;

public class ChildResponse {
    private boolean status;
    private String message;
    private int current_page;
    private List<Child> data;
    private String first_page_url;
    private int from;
    private int last_page;
    private String last_page_url;
    private List<Link> links;
    private String next_page_url;
    private String path;
    private int per_page;
    private String prev_page_url;
    private int to;
    private int total;

    public boolean isStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getCurrent_page() {
        return current_page;
    }

    public List<Child> getData() {
        return data;
    }

    public String getFirst_page_url() {
        return first_page_url;
    }

    public int getFrom() {
        return from;
    }

    public int getLast_page() {
        return last_page;
    }

    public String getLast_page_url() {
        return last_page_url;
    }

    public List<Link> getLinks() {
        return links;
    }

    public String getNext_page_url() {
        return next_page_url;
    }

    public String getPath() {
        return path;
    }

    public int getPer_page() {
        return per_page;
    }

    public String getPrev_page_url() {
        return prev_page_url;
    }

    public int getTo() {
        return to;
    }

    public int getTotal() {
        return total;
    }

    public class Link {
        private String url;
        private String label;
        private boolean active;

        public String getUrl() {
            return url;
        }

        public String getLabel() {
            return label;
        }

        public boolean isActive() {
            return active;
        }
    }
}
