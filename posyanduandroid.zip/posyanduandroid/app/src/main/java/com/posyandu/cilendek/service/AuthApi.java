package com.posyandu.cilendek.service;

import com.posyandu.cilendek.respon.AuthResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface AuthApi {
    @FormUrlEncoded
    @POST("login")
    Call<AuthResponse> login(
            @Field("email") String email,
            @Field("password") String password
    );


}
