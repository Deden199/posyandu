package com.posyandu.cilendek.service;

import com.posyandu.cilendek.model.Child;
import com.posyandu.cilendek.respon.ChildResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ChildApi {

    @POST("child")
    Call<Child> createChild(@Body Child child);

    @GET("child")
    Call<ChildResponse> searchChildren(@Header("Authorization") String token, @Query("search") String searchQuery);

    @GET("child/{id}")
    Call<ChildResponse> getChild(@Path("id") int childId);

    @GET("child")
    Call<ChildResponse> getChildren();
}

