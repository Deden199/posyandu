package com.posyandu.cilendek.service;

import com.posyandu.cilendek.model.Anak;

import java.util.ArrayList;

public class DataResponse {
    private ArrayList<Anak> data;

    public ArrayList<Anak> getData() {
        return data;
    }

    public void setData(ArrayList<Anak> data) {
        this.data = data;
    }
}
