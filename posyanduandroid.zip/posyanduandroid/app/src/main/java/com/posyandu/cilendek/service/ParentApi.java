package com.posyandu.cilendek.service;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ParentApi {
    @GET("parent")
    Call<ParentResponse> searchParents(@Query("search") String searchQuery);
}
