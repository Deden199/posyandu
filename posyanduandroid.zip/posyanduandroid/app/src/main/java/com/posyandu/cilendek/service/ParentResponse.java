package com.posyandu.cilendek.service;

import com.posyandu.cilendek.model.Parent;

import java.util.List;

public class ParentResponse {
    private boolean status;
    private String message;
    private int current_page;
    private List<Parent> data;
    private String first_page_url;
    private int from;
    private int last_page;
    private String last_page_url;
    private List<Link> links;
    private String next_page_url;
    private String path;
    private int per_page;
    private String prev_page_url;
    private int to;
    private int total;

    // Buat getter untuk semua properti

    public class Link {
        private String url;
        private String label;
        private boolean active;

        // Buat getter untuk semua properti
    }
}
